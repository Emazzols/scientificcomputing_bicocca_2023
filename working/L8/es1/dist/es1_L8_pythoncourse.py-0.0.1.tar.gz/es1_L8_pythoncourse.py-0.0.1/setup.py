from setuptools import setup, find_packages

setup(name='es1_L8_pythoncourse.py',
      description='some useful functions for data analysis',
      author='Emanuele Mazzola',
      version='0.0.1',
      packages=find_packages(),
      install_requires=['numpy', 'uproot'])